package com.example.ass7dialogrv

class Employee (val name : String, val gender : String, val email : String, val salary : Int) {
}